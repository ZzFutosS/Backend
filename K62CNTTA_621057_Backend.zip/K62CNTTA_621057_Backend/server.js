const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const auth = require('./middleware/auth');
const mongoose = require('mongoose');
const setRoutes = require('./routes');


mongoose.connect('mongodb+srv://backend:12345678b@cluster0.4m3ju.mongodb.net/backend?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(
    () => {console.log('Connected');},
    err => {console.log(err)}
);

const app = express();
app.set('views', './views');
app.set('view engine', 'pug');
app.set('ses', []);
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({
    extended: false,
}));
app.use(cookieParser());
app.use(auth);

setRoutes(app);

app.listen(3000, ()=> {
    console.log('Server on port 3000');
})
